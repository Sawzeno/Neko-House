// using UnityEditor;
// using UnityEngine;
//
// [CustomEditor(typeof(Multiplier))]
// // [CreatBoard]
// public class MultiplierEditor : Editor
// {
//   public override void OnInspectorGUI()
//   {
//     base.OnInspectorGUI();
//     // Multiplier multiplier = target as Multiplier;
//     Multiplier multiplier = (Multiplier) target;
//     if (GUILayout.Button("Create Board"))
//     {
//       multiplier.CreateBoard();
//     }
//     if (GUILayout.Button("destroy Board"))
//     {
//       multiplier.DestroyBoard();
//     }
//   }
// }
